document.getElementById('id_username').setAttribute('placeholder', 'Nome de usuário')
document.getElementById('id_email').setAttribute('placeholder', 'Endereço de E-mail')
document.getElementById('id_password1').setAttribute('placeholder', 'Crie uma senha')
document.getElementById('id_password2').setAttribute('placeholder', 'Digite a senha novamente')
